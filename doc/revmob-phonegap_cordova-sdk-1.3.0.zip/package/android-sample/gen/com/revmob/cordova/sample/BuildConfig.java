/** Automatically generated file. DO NOT MODIFY */
package com.revmob.cordova.sample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}